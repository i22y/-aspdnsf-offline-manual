// ------------------------------------------------------------------------------------------
// Copyright AspDotNetStorefront.com, 1995-2007.  All Rights Reserved.
// http://www.aspdotnetstorefront.com
// For details on this license please visit  the product homepage at the URL above.
// THE ABOVE NOTICE MUST REMAIN INTACT. 
// ------------------------------------------------------------------------------------------
using System;
using System.Security;
using System.Web;
using System.Web.Configuration;
using System.Web.Util;
using System.Configuration;
using System.Data;
using System.Text;
using System.IO;
using System.Net;
using System.Xml;
using System.Resources;
using System.Globalization;

namespace AspDotNetStorefrontCommon
{
    /// <summary>
    /// Summary description for CommonLogic.
    /// </summary>
    public class CommonLogic
    {

        public static String Application(String paramName)
        {
            String tmpS = String.Empty;
            if (System.Web.Configuration.WebConfigurationManager.AppSettings[paramName] != null)
            {
                try
                {
                    tmpS = System.Web.Configuration.WebConfigurationManager.AppSettings[paramName];
                }
                catch
                {
                    tmpS = String.Empty;
                }
            }
            return tmpS;
        }

        public static bool ApplicationBool(String paramName)
        {
            String tmpS = Application(paramName).ToUpperInvariant();
            return (tmpS == "TRUE" || tmpS == "YES" || tmpS == "1");
        }

        public static int ApplicationUSInt(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSInt(tmpS);
        }

        public static long ApplicationUSLong(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSLong(tmpS);
        }

        public static Single ApplicationUSSingle(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSSingle(tmpS);
        }

        public static Double ApplicationUSDouble(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSDouble(tmpS);
        }

        public static Decimal ApplicationUSDecimal(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSDecimal(tmpS);
        }

        public static DateTime ApplicationUSDateTime(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSDateTime(tmpS);
        }

        public static int ApplicationNativeInt(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeInt(tmpS);
        }

        public static long ApplicationNativeLong(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeLong(tmpS);
        }

        public static Single ApplicationNativeSingle(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeSingle(tmpS);
        }

        public static Double ApplicationNativeDouble(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeDouble(tmpS);
        }

        public static Decimal ApplicationNativeDecimal(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeDecimal(tmpS);
        }

        public static DateTime ApplicationNativeDateTime(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeDateTime(tmpS);
        }

        static public String UTF8ByteArrayToString(Byte[] characters)
        {

            UTF8Encoding encoding = new UTF8Encoding();
            String constructedString = encoding.GetString(characters);
            return constructedString;
        }

        static public String GetExceptionDetail(Exception ex, String LineSeparator)
        {
            String ExDetail = "Exception=" + ex.Message + LineSeparator;
            while (ex.InnerException != null)
            {
                ExDetail += ex.InnerException.Message + LineSeparator;
                ex = ex.InnerException;
            }
            return ExDetail;
        }


    }

}
