// ------------------------------------------------------------------------------------------
// Copyright AspDotNetStorefront.com, 1995-2007.  All Rights Reserved.
// http://www.aspdotnetstorefront.com
// For details on this license please visit  the product homepage at the URL above.
// THE ABOVE NOTICE MUST REMAIN INTACT. 
// ------------------------------------------------------------------------------------------
using System;
using System.Configuration;
using System.Xml;
using System.Web;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Threading;

namespace AspDotNetStorefrontCommon
{
    /// <summary>
    /// Summary description for Localization.
    /// </summary>
    public class Localization
    {
        static private CultureInfo USCulture = new CultureInfo("en-US");

        static private String WebConfigLocale = String.Empty;
        static private String SqlServerLocale = String.Empty;
        static private CultureInfo SqlServerCulture;
        static private Regex regInteger = new Regex(@"^-?\d+$");

        public Localization() { }

        static public void FlushCache()
        {
            try
            {
                HttpContext.Current.Cache.Remove("LocalesDoc");
            }
            catch { }
        }

        static public String GetWebConfigLocale()
        {
            if (WebConfigLocale.Length == 0)
            {
                // Set the path of the config file.
                String configPath = "~/web.config";

                // Get the Web application configuration object.
                System.Configuration.Configuration config = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration(configPath);

                // Get the section related object.
                System.Web.Configuration.GlobalizationSection configSection = (System.Web.Configuration.GlobalizationSection)config.GetSection("system.web/globalization");

                // Get/Set Culture
                WebConfigLocale = CheckLocaleSettingForProperCase(configSection.Culture);

            }
            return WebConfigLocale;
        }

        static public String GetUSLocale()
        {
            return "en-US";
        }

        static public String CheckLocaleSettingForProperCase(String LocaleSetting)
        {
            // make sure locale is xx-XX:
            int i = LocaleSetting.IndexOf("-");
            if (i != -1)
            {
                LocaleSetting = LocaleSetting.Substring(0, i) + "-" + LocaleSetting.Substring(i + 1, LocaleSetting.Length - (i + 1)).ToUpperInvariant();
            }
            return LocaleSetting;
        }

        static public String CheckCurrencySettingForProperCase(String CurrencySetting)
        {
            return CurrencySetting.ToUpperInvariant();
        }

        static public String GetSqlServerLocale()
        {
            if (SqlServerLocale.Length == 0)
            {
                SqlServerLocale = CommonLogic.Application("DBSQLServerLocaleSetting");
                SqlServerCulture = new CultureInfo(SqlServerLocale);
            }
            return SqlServerLocale;
        }

        static public String ShortDateFormat()
        {
            String tmp = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern.ToUpperInvariant();
            return tmp;
        }

        static public bool ParseBoolean(String s)
        {
            try
            {
                return System.Boolean.Parse(s);
            }
            catch
            {
                return false;
            }
        }

        static public int ParseUSInt(String s)
        {
            int usi;
            System.Int32.TryParse(s, NumberStyles.Integer, USCulture, out usi); // use default locale setting
            return usi;
        }

        static public int ParseNativeInt(String s)
        {
            int ni;
            System.Int32.TryParse(s, NumberStyles.Integer, Thread.CurrentThread.CurrentUICulture, out ni); // use default locale setting
            return ni;
        }

        static public long ParseUSLong(String s)
        {
            long usl;
            System.Int64.TryParse(s, NumberStyles.Integer, USCulture, out usl); // use default locale setting
            return usl;
        }

        static public long ParseNativeLong(String s)
        {
            long nl;
            System.Int64.TryParse(s, NumberStyles.Integer, Thread.CurrentThread.CurrentUICulture, out nl); // use default locale setting
            return nl;
        }

        static public Single ParseUSSingle(String s)
        {
            Single uss;
            System.Single.TryParse(s, NumberStyles.Number, USCulture, out uss);
            return uss;
        }

        static public Single ParseNativeSingle(String s)
        {
            Single ns;
            System.Single.TryParse(s, NumberStyles.Number, Thread.CurrentThread.CurrentUICulture, out ns);
            return ns;
        }

        static public Double ParseUSDouble(String s)
        {
            Double usd;
            System.Double.TryParse(s, NumberStyles.Number, USCulture, out usd);
            return usd;
        }

        static public Double ParseNativeDouble(String s)
        {
            Double nd;
            System.Double.TryParse(s, NumberStyles.Number, Thread.CurrentThread.CurrentUICulture, out nd);
            return nd;
        }

        static public decimal ParseUSCurrency(String s)
        {
            Decimal usc;
            System.Decimal.TryParse(s, NumberStyles.Currency, USCulture, out usc);
            return usc;
        }

        static public decimal ParseNativeCurrency(String s)
        {
            Decimal nc;
            System.Decimal.TryParse(s, NumberStyles.Currency, Thread.CurrentThread.CurrentUICulture, out nc);
            return nc;
        }

        static public decimal ParseUSDecimal(String s)
        {
            Decimal usd;
            System.Decimal.TryParse(s, NumberStyles.Number, USCulture, out usd);
            return usd;
        }

        static public decimal ParseNativeDecimal(String s)
        {
            Decimal nd;
            System.Decimal.TryParse(s, NumberStyles.Number, Thread.CurrentThread.CurrentUICulture, out nd);
            return nd;
        }

        static public DateTime ParseUSDateTime(String s)
        {
            try
            {
                return System.DateTime.Parse(s, USCulture);
            }
            catch
            {
                return System.DateTime.MinValue;
            }
        }

        static public DateTime ParseNativeDateTime(String s)
        {
            try
            {
                return System.DateTime.Parse(s); // use default locale setting
            }
            catch
            {
                return System.DateTime.MinValue;
            }
        }


        static public String ToUSShortDateString(DateTime dt)
        {
            if (dt == System.DateTime.MinValue)
            {
                return String.Empty;
            }
            return dt.ToString("MM/dd/yy"); //dt.Month.ToString().PadLeft(2,'0') + "/" + dt.Day.ToString().PadLeft(2,'0') + "/" + dt.Year.ToString().Substring(2,2);
        }

        static public String ToNativeShortDateString(DateTime dt)
        {
            if (dt == System.DateTime.MinValue)
            {
                return String.Empty;
            }
            return dt.ToShortDateString();
        }

        static public String ToUSDateTimeString(DateTime dt)
        {
            if (dt == System.DateTime.MinValue)
            {
                return String.Empty;
            }
            return dt.ToString("MM/dd/yyyy HH:mm:ss"); //dt.Month.ToString().PadLeft(2,'0') + "/" + dt.Day.ToString().PadLeft(2,'0') + "/" + dt.Year.ToString().Substring(2,2) + " " + dt.Hour.ToString().PadLeft(2,'0') + ":" + dt.Minute.ToString().PadLeft(2,'0') + ":" + dt.Second.ToString().PadLeft(2,'0') + "." + dt.Millisecond.ToString() + " " + dt.TimeOfDay;
        }

        static public String ToNativeDateTimeString(DateTime dt)
        {
            if (dt == System.DateTime.MinValue)
            {
                return String.Empty;
            }
            return dt.ToString(new CultureInfo(Localization.GetWebConfigLocale()));
        }

        static public String ToDBDateTimeString(DateTime dt)
        {
            return DateTimeStringForDB(dt);
        }

        static public String ToDBShortDateString(DateTime dt)
        {
            return DateStringForDB(dt);
        }


        // input amt is assumed to be in the store's PRIMARY CURRENCY!
        // NO formatting is applied. No exchange rates are applied
        // just returns xxxx.xx foramt
        static public String CurrencyStringForGatewayWithoutExchangeRate(decimal amt)
        {
            String s = amt.ToString("#.00", USCulture);
            if(s == ".00")
            {
                s = "0.00";
            }
            return s;
        }

        static public DateTime ParseDBDateTime(String s)
        {
            try
            {
                return System.DateTime.Parse(s, SqlServerCulture);
            }
            catch
            {
                return System.DateTime.MinValue;
            }
        }
        
        static public Double ParseDBDouble(String theval)
        {
            try
            {
                return System.Double.Parse(theval, SqlServerCulture);
            }
            catch
            {
                return 0.0D;
            }
        }

        static public Single ParseDBSingle(String theval)
        {
            try
            {
                return System.Single.Parse(theval, SqlServerCulture);
            }
            catch
            {
                return 0.0F;
            }
        }

        static public Decimal ParseDBDecimal(String theval)
        {
            try
            {
                return System.Decimal.Parse(theval, SqlServerCulture);
            }
            catch
            {
                return 0.0M;
            }
        }


        static public DateTime ParseLocaleDateTime(String theval, String LocaleSetting)
        {
            try
            {
                return System.DateTime.Parse(theval, new CultureInfo(LocaleSetting));
            }
            catch
            {
                return System.DateTime.MinValue;
            }
        }
        
        static public Double ParseLocaleDouble(String theval, String LocaleSetting)
        {
            try
            {
                return System.Double.Parse(theval, new CultureInfo(LocaleSetting));
            }
            catch
            {
                return 0.0D;
            }
        }

        static public Single ParseLocaleSingle(String theval, String LocaleSetting)
        {
            try
            {
                return System.Single.Parse(theval, new CultureInfo(LocaleSetting));
            }
            catch
            {
                return 0.0F;
            }
        }

        static public Decimal ParseLocaleDecimal(String theval, String LocaleSetting)
        {
            try
            {
                return System.Decimal.Parse(theval, new CultureInfo(LocaleSetting));
            }
            catch
            {
                return 0.0M;
            }
        }


        /// <summary>
        /// Converts a string in the SourceLocaleSetting format to a date string in the DestLocaleSetting format
        /// </summary>
        /// <param name="theval"></param>
        /// <param name="SourceLocaleSetting"></param>
        /// <param name="DestLocaleSetting"></param>
        /// <returns></returns>
        static public string ConvertLocaleDateTime(String theval, String SourceLocaleSetting, String DestLocaleSetting)
        {
            try
            {
                return System.DateTime.Parse(theval, new CultureInfo(SourceLocaleSetting)).ToString(new CultureInfo(DestLocaleSetting));
            }
            catch
            {
                return System.DateTime.MinValue.ToString(new CultureInfo(DestLocaleSetting));
            }
        }
        


        // ----------------------------------------------------------------------------------------------
        // the following routines must (should) work in ALL locales, no matter what SQL Server setting is
        // ----------------------------------------------------------------------------------------------
        static public String DateStringForDB(DateTime dt)
        {
            return dt.ToString("yyyyMMdd");
        }

        static public String DateTimeStringForDB(DateTime dt)
        {
            return dt.ToString("s");
        }

        static public String CurrencyStringForDBWithoutExchangeRate(decimal amt)
        {
            String tmpS = amt.ToString("C", USCulture);
            if (tmpS.StartsWith("("))
            {
                tmpS = "-" + tmpS.Replace("(", "").Replace(")", "");
            }
            return tmpS.Replace("$", "").Replace(",", "");
        }

        static public String IntStringForDB(int amt)
        {
            return amt.ToString("G", USCulture).Replace(",", "");
        }

        static public String SingleStringForDB(Single amt)
        {
            return amt.ToString("G", USCulture).Replace(",", "");
        }

        static public String DoubleStringForDB(double amt)
        {
            return amt.ToString("G", USCulture).Replace(",", "");
        }

        static public String DecimalStringForDB(decimal amt)
        {
            return amt.ToString("G", USCulture).Replace(",", "");
        }

        // ------------------------------------------------------------------------------
        // Type Formatting
        // ------------------------------------------------------------------------------
        public static string FormatDecimal2Places(decimal temp)
        {
            return temp.ToString("N2");
        }

        public static string FormatDecimal2Places(string temp)
        {
            decimal dec = Localization.ParseDBDecimal(temp);
            return dec.ToString("N2");
        }
    }
}
