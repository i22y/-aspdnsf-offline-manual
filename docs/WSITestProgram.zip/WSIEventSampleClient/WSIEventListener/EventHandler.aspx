﻿<%@ Page Language="C#" AutoEventWireup="true"  CodeFile="EventHandler.aspx.cs" Inherits="EventHandler" ValidateRequest="false" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>AspDotNetStorefront - WSI Event Listener Sample</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        AspDotNetStorefront - WSI Event Listener (Sample)<br />
        <br />
        <asp:Label ID="Label1" runat="server" Text="Label"></asp:Label></div>
    </form>
</body>
</html>
