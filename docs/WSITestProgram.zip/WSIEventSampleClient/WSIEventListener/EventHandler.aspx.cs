// ------------------------------------------------------------------------------------------
// Copyright AspDotNetStorefront.com, 1995-2007.  All Rights Reserved.
// http://www.aspdotnetstorefront.com
// For details on this license please visit  the product homepage at the URL above.
// THE ABOVE NOTICE MUST REMAIN INTACT. 
// ------------------------------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Text;
using System.Xml;
using System.IO;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using AspDotNetStorefrontCommon;

public partial class EventHandler : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // this is just a sample implementation. it just writes to the EventLog table of the specified db (in web.config)
        // you can then write another event monitor program (e.g. windows program) to poll that db and pull those records out 
        // and display/handle them if you want.
        //
        // see the windows client sample program provided. That windows program can then call WSI interface to get the data
        // from the storefront corresponding to the event. The event notification itself is kept small for efficiency.
        try
        {
            StringBuilder sb = new StringBuilder();
            int streamLength;
            int streamRead;
            Stream s = Request.InputStream;
            streamLength = Convert.ToInt32(s.Length);

            Byte[] streamArray = new Byte[streamLength];
            streamRead = s.Read(streamArray, 0, streamLength);
            for (int i = 0; i < streamLength; i++)
            {
                sb.Append(Convert.ToChar(streamArray[i]));
            }
            s.Dispose();

            if (sb.Length > 0)
            {

                // This assumes that the input data is Xml (our default as shipped) 
                // however the site admin could have designed the output WSI Event XmlPackage to send delimited text or some other format
                XmlDocument x = new XmlDocument();
                x.LoadXml(sb.ToString());

                XmlNode n = x.SelectSingleNode("/EventNotification");

                if (n != null)
                {
                    // do something with the incoming data
                    String ReportingDomain = XmlCommon.XmlField(n, "EventSite");
                    String EventType = XmlCommon.XmlField(n, "Event");
                    String EventXml = x.InnerXml;
                    if (EventType.Length != 0)
                    {
                        String sql = String.Format("insert EventLog(ReportingDomain,EventType,EventXml) values({0},{1},{2})", DB.SQuote(ReportingDomain), DB.SQuote(EventType.ToString()), DB.SQuote(EventXml));
                        DB.ExecuteSQL(sql);
                        Label1.Text = "OK";
                    }
                    else
                    {
                        Label1.Text = "Event Type Not Found In Xml Data";
                    }
                }
                else
                {
                    Label1.Text = "Event Xml Invalid Doc Structure";
                }
            }
            else
            {
                Label1.Text = "No Event Data Found";
            }
        }
        catch (Exception ex)
        {
            Label1.Text = ex.Message;
        }
    }
}
