// ------------------------------------------------------------------------------------------
// Copyright AspDotNetStorefront.com, 1995-2007.  All Rights Reserved.
// http://www.aspdotnetstorefront.com
// For details on this license please visit  the product homepage at the URL above.
// THE ABOVE NOTICE MUST REMAIN INTACT. 
// $Header: /v7.0/ASPDNSFCommon/CommonLogic.cs 17    10/03/06 9:27p Redwoodtree $
// ------------------------------------------------------------------------------------------
using System;
using System.Security;
using System.Configuration;
using System.Data;
using System.Text;
using System.Collections;
using System.IO;
using System.Net;
using System.Xml;
using System.Resources;
using System.Globalization;
using System.Collections.Specialized;
using System.IO.Compression;

namespace AspDotNetStorefrontCommon
{
    /// <summary>
    /// Summary description for CommonLogic.
    /// </summary>
    public class CommonLogic
    {
        public CommonLogic() { }

        // these are used for VB.NET compatibility
        static public int IIF(bool condition, int a, int b)
        {
            int x = 0;
            if (condition)
            {
                x = a;
            }
            else
            {
                x = b;
            }
            return x;
        }

        static public bool IIF(bool condition, bool a, bool b)
        {
            bool x = false;
            if (condition)
            {
                x = a;
            }
            else
            {
                x = b;
            }
            return x;
        }

        static public Single IIF(bool condition, Single a, Single b)
        {
            float x = 0;
            if (condition)
            {
                x = a;
            }
            else
            {
                x = b;
            }
            return x;
        }

        static public Double IIF(bool condition, double a, double b)
        {
            double x = 0;
            if (condition)
            {
                x = a;
            }
            else
            {
                x = b;
            }
            return x;
        }

        static public decimal IIF(bool condition, decimal a, decimal b)
        {
            decimal x = 0;
            if (condition)
            {
                x = a;
            }
            else
            {
                x = b;
            }
            return x;
        }

        static public String IIF(bool condition, String a, String b)
        {
            String x = String.Empty;
            if (condition)
            {
                x = a;
            }
            else
            {
                x = b;
            }
            return x;
        }

        public static int Min(int a, int b)
        {
            if (a < b)
            {
                return a;
            }
            return b;
        }

        public static int Max(int a, int b)
        {
            if (a > b)
            {
                return a;
            }
            return b;
        }

        public static decimal Min(decimal a, decimal b)
        {
            if (a < b)
            {
                return a;
            }
            return b;
        }

        public static decimal Max(decimal a, decimal b)
        {
            if (a > b)
            {
                return a;
            }
            return b;
        }

        public static Single Min(Single a, Single b)
        {
            if (a < b)
            {
                return a;
            }
            return b;
        }

        public static Single Max(Single a, Single b)
        {
            if (a > b)
            {
                return a;
            }
            return b;
        }

        public static DateTime Min(DateTime a, DateTime b)
        {
            if (a < b)
            {
                return a;
            }
            return b;
        }

        public static DateTime Max(DateTime a, DateTime b)
        {
            if (a > b)
            {
                return a;
            }
            return b;
        }


        public static String GetPhoneDisplayFormat(String PhoneNumber)
        {
            if (PhoneNumber.Length == 0)
            {
                return String.Empty;
            }
            if (PhoneNumber.Length != 11)
            {
                return PhoneNumber;
            }
            return "(" + PhoneNumber.Substring(1, 3) + ") " + PhoneNumber.Substring(4, 3) + "-" + PhoneNumber.Substring(7, 4);
        }

        public static bool IsNumber(string expression)
        {
            expression = expression.Trim();
            if (expression.Length == 0)
            {
                return false;
            }
            expression = expression.Replace(",", "").Replace(".", "").Replace("-", "");
            for (int i = 0; i < expression.Length; i++)
            {
                // only allow numeric digits
                if (!char.IsNumber(expression[i]))
                {
                    return false;
                }
            }
            return true;
        }

        public static bool IsInteger(string expression)
        {
            if (expression.Trim().Length == 0)
            {
                return false;
            }
            // leading - is ok
            expression = expression.Trim();
            int startIdx = 0;
            if (expression.StartsWith("-"))
            {
                startIdx = 1;
            }
            for (int i = startIdx; i < expression.Length; i++)
            {
                if (!char.IsNumber(expression[i]))
                {
                    return false;
                }
            }
            return true;
        }

        public static bool IsDate(string expression)
        {
            if (expression.Trim().Length == 0)
            {
                return false;
            }
            try
            {
                DateTime.Parse(expression);
                return true;
            }
            catch
            {
                return false;
            }
        }

        static public String GetExceptionDetail(Exception ex, String LineSeparator)
        {
            String ExDetail = "Exception=" + ex.Message + LineSeparator;
            while (ex.InnerException != null)
            {
                ExDetail += ex.InnerException.Message + LineSeparator;
                ex = ex.InnerException;
            }
            return ExDetail;
        }

        static public String Left(String s, int l)
        {
            if (s.Length <= l)
            {
                return s;
            }
            return s.Substring(0, l - 1);
        }

        // this really is never meant to be called with ridiculously  small l values (e.g. l < 10'ish)
        static public String Ellipses(String s, int l, bool BreakBetweenWords)
        {
            if (l < 1)
            {
                return String.Empty;
            }
            if (l >= s.Length)
            {
                return s;
            }
            String tmpS = Left(s, l - 2);
            if (BreakBetweenWords)
            {
                try
                {
                    tmpS = tmpS.Substring(0, tmpS.LastIndexOf(" "));
                }
                catch { }
            }
            tmpS += "...";
            return tmpS;
        }

        // this is probably the implementation that Microsoft SHOULD have done!
        // use this helper function for ALL MapPath calls in the entire storefront for safety!
        public static String SafeMapPath(String fname)
        {
            if (fname.StartsWith("\\\\"))
            {
                return fname;
            }

            string result = fname;
            //          string appPath = HttpContext.Current.Request.ApplicationPath;

            //Try it as a virtual path. Try to map it based on the Request.MapPath to handle Medium trust level and "~/" paths automatically 
            try
            {
                result = Path.Combine(System.Environment.CurrentDirectory,fname);
            }
            catch
            {
                //Didn't like something about the virtual path.
                //May be a drive path. See if it will expand to a valid path
                try
                {
                    //Try a GetFullPath. If the path is not virtual or has other malformed problems
                    //Return it as is
                    result = Path.GetFullPath(fname);
                }
                catch (NotSupportedException) // Contains a colon, probably already a full path.
                {
                    return fname;
                }
                catch (SecurityException exc)//Path is somewhere you're not allowed to access or is otherwise damaged
                {
                    throw new SecurityException("If you are running in Medium Trust you may have virtual directories defined that are not accessible at this trust level,\n " + exc.Message);
                }
            }
            return result;
        }

        public static String GetNewGUID()
        {
            return System.Guid.NewGuid().ToString().ToUpperInvariant();
        }

        // this version is NOT to be used to squote db sql stuff!
        public static String SQuote(String s)
        {
            return "'" + s.Replace("'", "''") + "'";
        }


        // this version is NOT to be used to squote db sql stuff!
        public static String DQuote(String s)
        {
            return "\"" + s.Replace("\"", "\"\"") + "\"";
        }

        public static String Application(String paramName)
        {
            XmlDocument d = new XmlDocument();
            try
            {
                d.Load(CommonLogic.SafeMapPath("app.config"));
            }
            catch
            {
                d.Load(CommonLogic.SafeMapPath("../../app.config"));
            }
            XmlNode n = d.SelectSingleNode("/configuration/appSettings/add[@key='" + paramName + "']");
            if(n == null)
            {
                return String.Empty;
            }
            return XmlCommon.XmlAttribute(n,"value");
        }

        public static bool ApplicationBool(String paramName)
        {
            String tmpS = Application(paramName).ToUpperInvariant();
            return (tmpS == "TRUE" || tmpS == "YES" || tmpS == "1");
        }

        public static int ApplicationUSInt(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSInt(tmpS);
        }

        public static long ApplicationUSLong(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSLong(tmpS);
        }

        public static Single ApplicationUSSingle(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSSingle(tmpS);
        }

        public static Double ApplicationUSDouble(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSDouble(tmpS);
        }

        public static Decimal ApplicationUSDecimal(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSDecimal(tmpS);
        }

        public static DateTime ApplicationUSDateTime(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseUSDateTime(tmpS);
        }

        public static int ApplicationNativeInt(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeInt(tmpS);
        }

        public static long ApplicationNativeLong(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeLong(tmpS);
        }

        public static Single ApplicationNativeSingle(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeSingle(tmpS);
        }

        public static Double ApplicationNativeDouble(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeDouble(tmpS);
        }

        public static Decimal ApplicationNativeDecimal(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeDecimal(tmpS);
        }

        public static DateTime ApplicationNativeDateTime(String paramName)
        {
            String tmpS = Application(paramName);
            return Localization.ParseNativeDateTime(tmpS);
        }
   }

}
