// ------------------------------------------------------------------------------------------
// Copyright AspDotNetStorefront.com, 1995-2007.  All Rights Reserved.
// http://www.aspdotnetstorefront.com
// For details on this license please visit  the product homepage at the URL above.
// THE ABOVE NOTICE MUST REMAIN INTACT. 
// ------------------------------------------------------------------------------------------
using System;
using System.Threading;
using System.Configuration;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Xml;
using System.IO;
using System.Xml.Xsl;
using System.Globalization;

namespace AspDotNetStorefrontCommon
{
    /// <summary>
    /// Summary description for DB.
    /// </summary>
    public class DB
    {

        static CultureInfo USCulture = new CultureInfo("en-US");
        static CultureInfo SqlServerCulture = new CultureInfo(CommonLogic.Application("DBSQLServerLocaleSetting"));

        public DB() { }

        static private String _activeDBConn = SetDBConn();
        static private String _NoLockString = " with (NOLOCK) ";

        static private String SetDBConn()
        {
            String s = CommonLogic.Application("ConnectionString");
            return s;
        }

        static public String GetDBConn()
        {
            return _activeDBConn;
        }

        static public String GetNoLock()
        {
            return _NoLockString;
        }

        public static String SQuote(String s)
        {
            return "N'" + s.Replace("'", "''") + "'";
        }

        public static String SQuoteNotUnicode(String s)
        {
            return "'" + s.Replace("'", "''") + "'";
        }

        public static String DateQuote(String s)
        {
            return "'" + s.Replace("'", "''") + "'";
        }

        public static String DateQuote(DateTime dt)
        {
            return DateQuote(Localization.ToDBDateTimeString(dt));
        }

        static public IDataReader GetRS(String Sql)
        {
            SqlConnection dbconn = new SqlConnection();
            dbconn.ConnectionString = DB.GetDBConn();
            dbconn.Open();
            SqlCommand cmd = new SqlCommand(Sql, dbconn);
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }


        static public void ExecuteSQL(String Sql)
        {
            SqlConnection dbconn = new SqlConnection();
            dbconn.ConnectionString = DB.GetDBConn();
            dbconn.Open();
            SqlCommand cmd = new SqlCommand(Sql, dbconn);
            try
            {
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                dbconn.Close();
                dbconn.Dispose();
            }
            catch (Exception ex)
            {
                cmd.Dispose();
                dbconn.Close();
                dbconn.Dispose();
                throw (ex);
            }
        }

        static public void ExecuteSQL(String Sql, SqlConnection dbconn)
        {
            SqlCommand cmd = new SqlCommand(Sql, dbconn);
            try
            {
                cmd.ExecuteNonQuery();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                cmd.Dispose();
                throw (ex);
            }
        }


        // ----------------------------------------------------------------
        //
        // SIMPLE RS FIELD ROUTINES
        //
        // ----------------------------------------------------------------

        public static String RSField(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return String.Empty;
                }
                return rs.GetString(idx);
        }

        public static bool RSFieldBool(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return false;
                }
                String s = rs[fieldname].ToString().ToUpperInvariant();
                return (s == "TRUE" || s == "YES" || s == "1");
        }

        public static String RSFieldGUID(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return String.Empty;
                }
                return rs.GetGuid(idx).ToString();
        }

        public static Guid RSFieldGUID2(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return new Guid("00000000000000000000000000000000");
                }
                return rs.GetGuid(idx);
        }

        public static Byte RSFieldByte(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return 0;
                }
                return rs.GetByte(idx);
        }

        public static int RSFieldInt(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return 0;
                }
                return rs.GetInt32(idx);
        }

        public static int RSFieldTinyInt(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return 0;
                }
                return Localization.ParseNativeInt(rs[idx].ToString());
        }

        public static long RSFieldLong(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return 0;
                }
                return rs.GetInt64(idx);
        }

        public static Single RSFieldSingle(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return 0.0F;
                }
                return (Single)rs.GetDouble(idx); // SQL server seems to fail the GetFloat calls, so we have to do this
        }

        public static Double RSFieldDouble(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return 0.0F;
                }
                return rs.GetDouble(idx);
        }

        public static Decimal RSFieldDecimal(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return System.Decimal.Zero;
                }
                return rs.GetDecimal(idx);
        }

        public static DateTime RSFieldDateTime(IDataReader rs, String fieldname)
        {
                int idx = rs.GetOrdinal(fieldname);
                if (rs.IsDBNull(idx))
                {
                    return System.DateTime.MinValue;
                }
                return Convert.ToDateTime(rs[idx], SqlServerCulture);
                //return rs.GetDateTime(idx);
        }

        public static String GetNewGUID()
        {
            return System.Guid.NewGuid().ToString();
        }

    }

}
