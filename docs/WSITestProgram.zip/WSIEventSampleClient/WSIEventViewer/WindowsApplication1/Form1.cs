using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Xml;
using System.IO;
using System.Windows.Forms;
using AspDotNetStorefrontCommon;

namespace WindowsApplication1
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
        }

        // this is just a sample implementation to show concepts. a real world prdouction client event handler would have much more robust
        // error handling, retry logic, etc...
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            try
            {
                IDataReader rs = DB.GetRS("aspdnsf_GetNewEvents");
                while (rs.Read())
                {
                    String EventType = DB.RSField(rs, "EventType");
                    String EventXml = DB.RSField(rs, "EventXml");

                    OutputXml.Text += String.Format("Event: {0}, Domain={1}, Time={2}{3}", EventType, DB.RSField(rs, "ReportingDomain"), DB.RSFieldDateTime(rs, "CreatedOn").ToString(), Environment.NewLine);
                    OutputXml.Text += String.Format("Event Xml: {0}{1}", XmlCommon.PrettyPrintXml(EventXml), Environment.NewLine);

                    String EventTypeLower = EventType.ToLowerInvariant();

                    
                    // this is just simple (crude) example with a lot of hard-coded data, normally, a proper production WSI event handler client
                    // would setup a db to define events, and all, and then match them against incoming data
                    //
                    // remember the store developer/admin could have added other events to their storefront. These are just the default ones we 
                    // provided as shipped. Also, they store developer/admin could have changed the event data that comes in on each one.
                    //
                    // for example, we just show the CreateCustomer and NewOrder about how the WSI could be used to get the actual event data
                    //
                    XmlDocument EventXmlDoc = new XmlDocument();
                    EventXmlDoc.LoadXml(EventXml);
                    
                    if (EventTypeLower == "addtocart")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "begincheckout")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "checkoutpayment")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "checkoutreview")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "checkoutshipping")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "createaccount")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "createcustomer")
                    {
                        // sample of how to get Customer Data by calling WSI back
                        // in production apps, you would not hard code emails and all, and we are using the non WSE3 call here
                        // just for simplicity, but in production, you should use a fully secured https WSE3 WSI invocation
                        // per the WSI manual security setup guidelines
                        try
                        {
                            String CustomerID = EventXmlDoc.SelectSingleNode("/EventNotification/EventData/CustomerID").InnerText;
                            
                            WSI.AspDotNetStorefrontImportWebService svc = new WSI.AspDotNetStorefrontImportWebService();
                            String WSIRequestXmlDoc = String.Format("<AspDotNetStorefrontImport><GetCustomer CustomerID=\"{0}\"/></AspDotNetStorefrontImport>", CustomerID);
                            String WSIResponseXmlDoc = svc.DoItUsernamePwd("admin@aspdotnetstorefront.com", "Admin$11", WSIRequestXmlDoc);

                            OutputXml.Text += String.Format("Customer Data: {0}{1}", XmlCommon.PrettyPrintXml(WSIResponseXmlDoc), Environment.NewLine);
                        }
                        catch (Exception ex)
                        {
                            OutputXml.Text += String.Format("Error Getting Customer Data: {0}{1}", CommonLogic.GetExceptionDetail(ex, Environment.NewLine), Environment.NewLine);
                        }

                    }
                    if (EventTypeLower == "deletecustomer")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "neworder")
                    {
                        // sample of how to get Order Data by calling WSI back (not getting CC info here, but you could via WSI)
                        // in production apps, you would not hard code emails and all, and we are using the non WSE3 call here
                        // just for simplicity, but in production, you should use a fully secured https WSE3 WSI invocation
                        // per the WSI manual security setup guidelines. This example assumes v7.0.2.5 WSI calls. Consult your wsi.xml master spec
                        // for the WSI call to retrieve order information for your version (e.g. GetOrder was just added in v7.0.2.5)
                        try
                        {
                            String OrderNumber = EventXmlDoc.SelectSingleNode("/EventNotification/EventData/OrderNumber").InnerText;

                            WSI.AspDotNetStorefrontImportWebService svc = new WSI.AspDotNetStorefrontImportWebService();
                            String WSIRequestXmlDoc = String.Format("<AspDotNetStorefrontImport><GetOrder OrderNumber=\"{0}\"/></AspDotNetStorefrontImport>", OrderNumber);
                            String WSIResponseXmlDoc = svc.DoItUsernamePwd("admin@aspdotnetstorefront.com", "Admin$11", WSIRequestXmlDoc);

                            OutputXml.Text += String.Format("Order Data: {0}{1}", XmlCommon.PrettyPrintXml(WSIResponseXmlDoc), Environment.NewLine);
                        }
                        catch (Exception ex)
                        {
                            OutputXml.Text += String.Format("Error Getting Order Data: {0}{1}", CommonLogic.GetExceptionDetail(ex, Environment.NewLine), Environment.NewLine);
                        }
                    }
                    if (EventTypeLower == "nukecustomer")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "orderdeleted")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "orderrefunded")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "ordershipped")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "ordervoided")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "removefromcart")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "updatecustomer")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "viewentitypage")
                    {
                        // do whatever you want here...
                    }
                    if (EventTypeLower == "viewproductpage")
                    {
                        // do whatever you want here...
                    }

                }
                rs.Close();
            }
            catch (Exception ex)
            {
                OutputXml.Text += ex.Message + Environment.NewLine;
            }
            timer1.Enabled = true;
        }

    }
}