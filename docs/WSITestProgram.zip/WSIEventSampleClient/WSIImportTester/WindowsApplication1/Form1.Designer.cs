namespace WindowsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.InputXml = new System.Windows.Forms.TextBox();
            this.OutputXml = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.EMail = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.WSIURL = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.UseWSE3 = new System.Windows.Forms.CheckBox();
            this.ShowRawErrors = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 299);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "GO!";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // InputXml
            // 
            this.InputXml.AcceptsReturn = true;
            this.InputXml.AcceptsTab = true;
            this.InputXml.HideSelection = false;
            this.InputXml.Location = new System.Drawing.Point(13, 38);
            this.InputXml.MaxLength = 1000000;
            this.InputXml.Multiline = true;
            this.InputXml.Name = "InputXml";
            this.InputXml.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.InputXml.Size = new System.Drawing.Size(940, 255);
            this.InputXml.TabIndex = 1;
            this.InputXml.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.InputXml_KeyPress);
            this.InputXml.KeyDown += new System.Windows.Forms.KeyEventHandler(this.InputXml_KeyDown);
            // 
            // OutputXml
            // 
            this.OutputXml.AcceptsReturn = true;
            this.OutputXml.AcceptsTab = true;
            this.OutputXml.HideSelection = false;
            this.OutputXml.Location = new System.Drawing.Point(12, 328);
            this.OutputXml.MaxLength = 1000000;
            this.OutputXml.Multiline = true;
            this.OutputXml.Name = "OutputXml";
            this.OutputXml.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.OutputXml.Size = new System.Drawing.Size(940, 408);
            this.OutputXml.TabIndex = 2;
            this.OutputXml.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.OutputXml_KeyPress);
            this.OutputXml.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OutputXml_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(493, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "E-Mail:";
            // 
            // EMail
            // 
            this.EMail.Location = new System.Drawing.Point(536, 6);
            this.EMail.Name = "EMail";
            this.EMail.Size = new System.Drawing.Size(180, 20);
            this.EMail.TabIndex = 4;
            this.EMail.Text = "admin@aspdotnetstorefront.com";
            // 
            // Password
            // 
            this.Password.AcceptsReturn = true;
            this.Password.AcceptsTab = true;
            this.Password.Location = new System.Drawing.Point(772, 6);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(180, 20);
            this.Password.TabIndex = 6;
            this.Password.WordWrap = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(718, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Password:";
            // 
            // WSIURL
            // 
            this.WSIURL.Location = new System.Drawing.Point(46, 6);
            this.WSIURL.Name = "WSIURL";
            this.WSIURL.Size = new System.Drawing.Size(241, 20);
            this.WSIURL.TabIndex = 8;
            this.WSIURL.Text = "http://localhost/aspdotnetstorefront71/ipx.asmx";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "WSI:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(294, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Use WSE3 Token Authentication:";
            // 
            // UseWSE3
            // 
            this.UseWSE3.AutoSize = true;
            this.UseWSE3.Checked = true;
            this.UseWSE3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.UseWSE3.Location = new System.Drawing.Point(460, 10);
            this.UseWSE3.Name = "UseWSE3";
            this.UseWSE3.Size = new System.Drawing.Size(15, 14);
            this.UseWSE3.TabIndex = 10;
            this.UseWSE3.UseVisualStyleBackColor = true;
            // 
            // ShowRawErrors
            // 
            this.ShowRawErrors.AutoSize = true;
            this.ShowRawErrors.Location = new System.Drawing.Point(108, 303);
            this.ShowRawErrors.Name = "ShowRawErrors";
            this.ShowRawErrors.Size = new System.Drawing.Size(108, 17);
            this.ShowRawErrors.TabIndex = 11;
            this.ShowRawErrors.Text = "Show Raw Errors";
            this.ShowRawErrors.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(805, 299);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(132, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "Pretty Print Xml Above";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(977, 748);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.ShowRawErrors);
            this.Controls.Add(this.UseWSE3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.WSIURL);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.EMail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.OutputXml);
            this.Controls.Add(this.InputXml);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "AspDotNetStorefront - WSI Test Client";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox InputXml;
        private System.Windows.Forms.TextBox OutputXml;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox EMail;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox WSIURL;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox UseWSE3;
        private System.Windows.Forms.CheckBox ShowRawErrors;
        private System.Windows.Forms.Button button2;
    }
}

