using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Xml;
using System.IO;
using System.Windows.Forms;
using Microsoft.Web.Services3;
using Microsoft.Web.Services3.Design;
using Microsoft.Web.Services3.Security;
using Microsoft.Web.Services3.Security.Tokens;

namespace WindowsApplication1
{
    public partial class Form1 : Form
    {

        bool keyHandled = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                OutputXml.Text = "working...";
                OutputXml.Refresh();
                String Result = String.Empty;
                if (InputXml.Text.Trim().Length == 0)
                {
                    OutputXml.Text = "Nothing to do!";
                }
                else
                {
                    if (UseWSE3.Checked)
                    {
                        UsernameToken token = new UsernameToken(EMail.Text, Password.Text, PasswordOption.SendHashed);
                        WSI.AspDotNetStorefrontImportWebServiceWse svc = new WSI.AspDotNetStorefrontImportWebServiceWse();
                        svc.Url = WSIURL.Text;
                        //svc.SetPolicy("UserNameToken");
                        //svc.SetClientCredential(token);
                        svc.RequestSoapContext.Security.Tokens.Add(token);
                        Result = svc.DoItWSE3(InputXml.Text.Trim());
                    }
                    else
                    {
                        WSI.AspDotNetStorefrontImportWebService svc = new WSI.AspDotNetStorefrontImportWebService();
                        svc.Url = WSIURL.Text;
                        Result = svc.DoItUsernamePwd(EMail.Text, Password.Text, InputXml.Text.Trim());
                    }
                    OutputXml.Text = PrettyPrintXml(Result);
                }
            }
            catch (Exception ex)
            {
                if (UseWSE3.Checked && !ShowRawErrors.Checked && ex.Message.ToLowerInvariant().IndexOf("the computed password digest doesn't match that of the incoming username token") != -1)
                {
                    OutputXml.Text = "Authentication Failure. Probably an invalid Password specified? When using WSE3, you must enter here the master hashed password from the AspDotNetStorefront database (do not use the clear text password)";
                }
                else if (UseWSE3.Checked && !ShowRawErrors.Checked && ex.Message.ToLowerInvariant().IndexOf("the incoming username token contains a password hash") != -1)
                {
                    OutputXml.Text = "Authentication Failure. Probably an invalid E-Mail specified?";
                }
                else
                {
                    OutputXml.Text = ex.Message;
                }
            }
        }

        public static String PrettyPrintXml(String Xml)
        {
            String Result = Xml;
            if (Xml.Length != 0)
            {
                //Xml = Xml.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
                try
                {
                    // Load the XmlDocument with the Xml.
                    XmlDocument D = new XmlDocument();
                    D.LoadXml(Xml);
                    MemoryStream MS = new MemoryStream();
                    XmlTextWriter W = new XmlTextWriter(MS, Encoding.Unicode);

                    W.Formatting = Formatting.Indented;

                    // Write the Xml into a formatting XmlTextWriter
                    D.WriteContentTo(W);
                    W.Flush();
                    MS.Flush();

                    // Have to rewind the MemoryStream in order to read
                    // its contents.
                    MS.Position = 0;

                    // Read MemoryStream contents into a StreamReader.
                    StreamReader SR = new StreamReader(MS);

                    // Extract the text from the StreamReader.
                    String FormattedXml = SR.ReadToEnd();

                    Result = FormattedXml;

                    try
                    {
                        MS.Close();
                        MS = null;
                        W.Close();
                        W = null;
                    }
                    catch { }
                }
                catch { }
            }
            return Result;
        }

        private void InputXml_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            keyHandled = false;

            if (e.Control && e.KeyCode == Keys.A)
            {
                ((TextBox)sender).SelectAll();
                ((TextBox)sender).Focus();
                keyHandled = true;
            }
        }

        private void InputXml_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (keyHandled)
            {
                e.Handled = true;
            }
        }

        private void OutputXml_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            keyHandled = false;


            if (e.Control && e.KeyCode == Keys.A)
            {
                ((TextBox)sender).SelectAll();
                ((TextBox)sender).Focus();
                keyHandled = true;
            }
        }

        private void OutputXml_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (keyHandled)
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String s = InputXml.Text;
            try
            {
                InputXml.Text = PrettyPrintXml(s);
            }
            catch
            {
                InputXml.Text = s;
            }
        }

    }
}