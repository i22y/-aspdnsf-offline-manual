-- ------------------------------------------------------------------------------------------
-- Copyright AspDotNetStorefront.com, 1995-2007.  All Rights Reserved.
-- http://www.aspdotnetstorefront.com
-- For details on this license please visit our homepage at the URL above.
-- THE ABOVE NOTICE MUST REMAIN INTACT. 
--
-- WSI Event Reporting Database Creation Script: AspDotNetStorefront Version ML 7.0
-- Microsoft SQL Server 2000 Or higher
-- ------------------------------------------------------------------------------------------

-- change this line to match your database name, or set the database context manually in query analyzer and delete the next line:
--use WSIEventLog
go

set nocount on;
GO

CREATE TABLE [dbo].[EventLog](
	[EventLogID] [int] IDENTITY(1,1) NOT NULL,
	[EventLogGUID] [uniqueidentifier] NOT NULL CONSTRAINT DF_EventLog_EventLogGUID DEFAULT (newid()),
	[ReportingDomain] [nvarchar](100) NOT NULL,
	[EventType] [nvarchar](100) NOT NULL,
	[EventXml] [ntext] NULL,
	[IsNew] [tinyint] NOT NULL CONSTRAINT DF_EventLog_IsNew default(1),
	[CreatedOn] [datetime] NOT NULL CONSTRAINT DF_EventLog_CreatedOn DEFAULT (getdate()),
	[ReadOn] [datetime] NULL ,
     CONSTRAINT [PK_EventLog] PRIMARY KEY CLUSTERED 
    (
        [EventLogID] ASC
    )
)
GO

IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[aspdnsf_GetNewEvents]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[aspdnsf_GetNewEvents]
GO
create proc dbo.aspdnsf_GetNewEvents
AS
BEGIN
SET NOCOUNT ON 
	begin tran
	update EventLog with (rowlock) set ReadOn=getdate(), IsNew=2 where IsNew=1
	select * from EventLog where IsNew=2
	update EventLog set IsNew=0 where IsNew=2
	commit tran
END
GO


