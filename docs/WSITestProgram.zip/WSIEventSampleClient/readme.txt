This is a sample AspDotNetStorefront ML WSI Event Listener web site and windows client.

For WSI documentation, refer to http://www.aspdotnetstorefront.com/manual/wsi

This sample WSI event listener shows you how to setup a web site that can listen to
AspDotNetStorefront events, such as New Customer, Add To Cart, Checkout Started, New Order, etc...

The sample consists of 3 parts:

a) SQL Server database: Create a WSIEventLog db by running the db/createeventlog.sql

b) Web listener: This is the web site page called by the storefront. You have to setup this callback
WSI Event url on your AspDotNetStorefront Admin site following the WSI Manual instructions.
For example purposes, we can assume you will set it up as:

http://localhost/WSIEventListener/EventHandler.aspx

This web page listener receives events from your storefront, when enabled, and stores the events, 
and event Xml into the WSIEventLog database.

c) Windows Client: This program polls the WSIEventLog database looking for new events, and
just displays them on the screen. A production site client would of course do more processing
on the events, and probably even call the storefront WSI API to get the actual event data. 
For simplicity, we just dump the event to the screen, along with the Xml.

Thanks.
AspDotNetStorefront Team.
